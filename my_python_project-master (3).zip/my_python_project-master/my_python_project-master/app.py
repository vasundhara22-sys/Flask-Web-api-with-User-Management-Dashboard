from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Create db instance **without binding to app**
db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Bind db to app
    db.init_app(app)

    # Import blueprints after db init
    from users import users_bp
    app.register_blueprint(users_bp)

    from flask import render_template
    @app.route("/")
    def dashboard():
        return render_template("dashboard.html")

    # Create tables within app context
    with app.app_context():
        from models import User
        db.create_all()

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
