from flask import Blueprint, request, jsonify

users_bp = Blueprint("users_bp", __name__)

# In-memory users list
users = []

# Utility to get user by ID
def get_user_by_id(user_id):
    return next((u for u in users if u["id"] == user_id), None)

# GET all users with optional search
@users_bp.route("/users", methods=["GET"])
def get_users():
    query = request.args.get("q", "").lower()
    if query:
        filtered = [u for u in users if query in u["name"].lower() or query in u["email"].lower()]
        return jsonify(filtered)
    return jsonify(users)

# POST add new user
@users_bp.route("/users", methods=["POST"])
def add_user():
    data = request.json
    if not data.get("name") or not data.get("email"):
        return jsonify({"error": "Name and Email required"}), 400
    # Check for duplicate email
    if any(u["email"] == data["email"] for u in users):
        return jsonify({"error": "Email already exists"}), 400
    user = {
        "id": len(users) + 1,
        "name": data["name"],
        "email": data["email"],
        "role": data.get("role", "user"),  # New field: role
        "status": data.get("status", "active")  # New field: status
    }
    users.append(user)
    return jsonify(user), 201

# PUT update user
@users_bp.route("/users/<int:user_id>", methods=["PUT"])
def update_user(user_id):
    user = get_user_by_id(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.json
    user["name"] = data.get("name", user["name"])
    if "email" in data:
        if any(u["email"] == data["email"] and u["id"] != user_id for u in users):
            return jsonify({"error": "Email already exists"}), 400
        user["email"] = data["email"]
    user["role"] = data.get("role", user.get("role", "user"))
    user["status"] = data.get("status", user.get("status", "active"))

    return jsonify(user)

# DELETE user
@users_bp.route("/users/<int:user_id>", methods=["DELETE"])
def delete_user(user_id):
    global users
    user = get_user_by_id(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    users = [u for u in users if u["id"] != user_id]
    return jsonify({"message": "User deleted"})

# PATCH toggle user status
@users_bp.route("/users/<int:user_id>/status", methods=["PATCH"])
def toggle_status(user_id):
    user = get_user_by_id(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    user["status"] = "inactive" if user["status"] == "active" else "active"
    return jsonify(user)
