let editId = null;

async function fetchUsers() {
  const query = document.getElementById("search").value;
  const res = await fetch(`/users?q=${query}`);
  const users = await res.json();

  const tbody = document.querySelector("#userTable tbody");
  tbody.innerHTML = "";

  users.forEach((u) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
            <td>${u.id}</td>
            <td>${u.name}</td>
            <td>${u.email}</td>
            <td>${u.role}</td>
            <td>
                <button onclick="toggleStatus(${u.id})" class="${
      u.status === "active" ? "active" : "inactive"
    }">
                    ${u.status}
                </button>
            </td>
            <td>
                <button class="edit" onclick="startEdit(${u.id},'${u.name}','${
      u.email
    }','${u.role}')">Edit</button>
                <button class="delete" onclick="deleteUser(${
                  u.id
                })">Delete</button>
            </td>
        `;
    tbody.appendChild(tr);
  });
}

async function addUser() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const role = document.getElementById("role").value;

  if (!name || !email) {
    alert("Name and Email required");
    return;
  }

  if (editId) {
    await fetch(`/users/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, role }),
    });
    editId = null;
    document.getElementById("submitBtn").textContent = "Add User";
  } else {
    await fetch("/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, role }),
    });
  }

  document.getElementById("name").value = "";
  document.getElementById("email").value = "";
  fetchUsers();
}

function startEdit(id, name, email, role) {
  editId = id;
  document.getElementById("name").value = name;
  document.getElementById("email").value = email;
  document.getElementById("role").value = role;
  document.getElementById("submitBtn").textContent = "Update User";
}

async function deleteUser(id) {
  if (confirm("Are you sure?")) {
    await fetch(`/users/${id}`, { method: "DELETE" });
    fetchUsers();
  }
}

async function toggleStatus(id) {
  await fetch(`/users/${id}/status`, { method: "PATCH" });
  fetchUsers();
}

// Event listeners
document.getElementById("submitBtn").addEventListener("click", addUser);
document.getElementById("search").addEventListener("input", fetchUsers);

// Initial load
fetchUsers();
